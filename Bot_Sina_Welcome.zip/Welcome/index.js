const { Client, Intents, MessageEmbed, Permissions } = require('discord.js');
const Discord = require("discord.js");
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const token = require('./config.json');
require('discord-reply');


client.on("ready" , () => {
    const server = client.guilds.cache.get("SERVER ID")
          client.user.setActivity(`${server.memberCount} Members`, {type:"STREAMING"})
        console.log(`Logged in as ${client.user.tag}!`);

})

client.on('guildMemberAdd', member => {
    let welcomeChannel = client.channels.cache.get("CHANNEL ID")
    if (welcomeChannel) {

        let welcomeEmbed = new Discord.MessageEmbed()
        if (member.user) {

            if (member.user.client) {

                welcomeEmbed.setColor("RANDOM")
                welcomeEmbed.setImage("https://cdn.discordapp.com/attachments/931918838004613150/964577731935338516/welc23ome.png")
                welcomeEmbed.setAuthor('IПFIПITY TΣΛM',(member.user.displayAvatarURL()),' https://idpay.ir/infinity-team')
                welcomeEmbed.setDescription(`
                  ** 👋 〢 Hey  <@${member.user.id}> Welcome To IПFIПITY TΣΛM** \n \n  ** 👥 〢 Member Count : ${member.guild.memberCount} \n \n **  ** 📜 〢 Please Follow The __Rules__**`)
                welcomeEmbed.setThumbnail("https://cdn.discordapp.com/icons/810875949188382731/a_d6ce5c220f0f734a1fedabfce2f1b0c8.gif?size=4096")
                welcomeEmbed.setFooter('IПFIПITY TΣΛM','https://cdn.discordapp.com/icons/810875949188382731/a_d6ce5c220f0f734a1fedabfce2f1b0c8.gif?size=4096');
                welcomeChannel.send(`<@${member.user.id}>`, welcomeEmbed)
            }
        }
    } else {
        console.log("welcome channel peyda nashod".red)
    }
})

client.login(token)